from setuptools import setup

setup(
	name="hello",
	version="0.1",
	descriptino="my hello library",
	author="Danny Chun",
	author_email="jaeyoung.chun@gmail.com",
	url="https://github.com/hisplan",
	packages=['module_a', 'module_a.m1', 'module_a.m2']
)
