def bar():
	return "bar"
