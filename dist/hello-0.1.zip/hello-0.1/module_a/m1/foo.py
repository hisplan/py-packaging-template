def foo():
	return "foo"